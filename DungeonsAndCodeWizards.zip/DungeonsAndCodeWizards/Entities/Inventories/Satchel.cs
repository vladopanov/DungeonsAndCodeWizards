﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Entities.Inventories
{
    public class Satchel : Bag
    {
        public Satchel() : base(capacity: 20)
        {
        }
    }
}
